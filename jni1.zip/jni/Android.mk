LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE := libdobby
LOCAL_SRC_FILES := vendor/Dobby/$(TARGET_ARCH_ABI)/libdobby.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)

LOCAL_MODULE := plugin

# Пути для заголовков
LOCAL_C_INCLUDES := \
    $(LOCAL_PATH)/vendor/Dobby/include \
    $(LOCAL_PATH)/vendor/imgui \
    $(LOCAL_PATH)/vendor/xorstr

# Статические библиотеки
LOCAL_STATIC_LIBRARIES := libdobby

# Флаги линковки
LOCAL_LDFLAGS := -llog

# Флаги компиляции
LOCAL_CPPFLAGS := -std=c++17 -O2 -fvisibility=hidden
LOCAL_CFLAGS := -O2 -fvisibility=hidden
LOCAL_CPPFLAGS += -Wno-error=format-security

# Ищем все .cpp файлы (рекурсивно)
CPP_FILES := $(shell find $(LOCAL_PATH) -name "*.cpp" -not -path "*/vendor/*")
LOCAL_SRC_FILES := $(CPP_FILES:$(LOCAL_PATH)/%=%)

# Если есть .c файлы
# C_FILES := $(shell find $(LOCAL_PATH) -name "*.c" -not -path "*/vendor/*")
# LOCAL_SRC_FILES += $(C_FILES:$(LOCAL_PATH)/%=%)

# Включаем исключительно для Android
LOCAL_LDLIBS := -lEGL -lGLESv3 -llog -lz

include $(BUILD_SHARED_LIBRARY)