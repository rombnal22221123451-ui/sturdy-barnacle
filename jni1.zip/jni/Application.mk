APP_ABI := all
APP_PLATFORM := android-26
APP_CPPFLAGS := -std=c++17
APP_STL := c++_static