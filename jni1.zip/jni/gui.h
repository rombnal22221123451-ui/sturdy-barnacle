#pragma once
#include <vendor/imgui/imgui.h>
#include <vendor/imgui/backends/imgui_impl_opengl3.h>
#include <vendor/imgui/backends/imgui_impl_android.h>

#include <vendor/xorstr/xorstr.h>

namespace UI {
    void Init();
    void Resize(int x, int y);
    void Render();
    void Shutdown();
}