#include <vendor/xorstr/xorstr.h>
#include <vendor/Dobby/include/dobby.h>
#include <EGL/egl.h>
#include <gui.h>
#include <jni.h>
#include <link.h>
#include <stdio.h>
#include <string.h>
#include <thread>
#include <iostream>
#include <cstdint>

static uptr_t g_module = 0;
static bool inited = false;

static int basepacket(struct dl_phdr_info *info, size_t size) {
    if (info->dlpi_name && strstr(info->dlpi_name, xorstr("libblackrussia-client.so"))) {
        g_module = info->dlpi_addr;
        return 1;
    }
    return 0;
}

void (*ChatOrig)(const char* arg1, int64_t arg_f0h) = nullptr;
void ChatHook(const char* arg1, int64_t arg_f0h) {
    int x, y;
    if (strcmp(arg1, xorstr("!start")) == 0) {
        return;
    }
    if (sscanf(arg1, xorstr("!resize %d %d"), &x, &y) == 2) {
        UI::Resize(x, y);
        return;
    }
    
    if (strcmp(arg1, xorstr("!stop")) == 0) {
        UI::Shutdown();
        return;
    }

    ChatOrig(arg1, arg_f0h);
}

EGLBoolean (*eglswapbuffer_o)(EGLDisplay dpy, EGLSurface surface) = nullptr;
EGLBoolean eglswapbuffer_h(EGLDisplay dpy, EGLSurface surface) {
    if (!inited) {
        UI::Init();
        EGLint width, height;
        eglQuerySurface(dpy, surface, EGL_WIDTH, &width);
        eglQuerySurface(dpy, surface, EGL_HEIGHT, &height);
        UI::Resize(width, height);
        inited = true;
    }
    UI::Render();
    
    return eglswapbuffer_o(dpy, surface);
}

void start() {
    while (g_module == 0) {
        dl_iterate_phdr(basepacket);
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
    DobbyHook((void*)(g_module + 0x00c49c54), (void*)ChatHook, (void**)&ChatOrig);
    void* eglSwapBuffers_addr = nullptr;
    while (!eglSwapBuffers_addr) {
    eglSwapBuffers_addr = DobbySymbolResolver("libEGL.so", "eglSwapBuffers");
    std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
    DobbyHook(eglSwapBuffers_addr, (void*)eglswapbuffer_h, (void**)&eglswapbuffer_o);
    
}

JNIEXPORT jint JNI_OnLoad(JavaVM* vm, void* reserved) {
    std::thread worker(start);
    worker.detach();
    return JNI_VERSION_1_6;
}