#include <vendor/xorstr/xorstr.h>
#include <vendor/Dobby/include/dobby.h>
#include <jni.h>
#include <link.h>
#include <stdio.h>
#include <string.h>
#include <thread>
#include <iostream>
#include <cstdint>

static uptr_t g_module = 0;

static int basepacket(struct dl_phdr_info *info, size_t size) {
    if (info->dlpi_name && strstr(info->dlpi_name, xorstr("libblackrussia-client.so"))) {
        g_module = info->dlpi_addr;
        return 1;
    }
    return 0;
}

void (*ChatOrig)(const char* arg1, int64_t arg_f0h) = nullptr;
void ChatHook(const char* arg1, int64_t arg_f0h) {
    if (arg1 && strcmp(arg1, "/start") == 0) {
        return;
    }
    ChatOrig(arg1, arg_f0h);
}

void start() {
    while (g_module == 0) {
        dl_iterate_phdr(basepacket);
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
    DobbyHook((void*)(g_module + 0x00c49c54), (void*)ChatHook, (void**)&ChatOrig);
}

JNIEXPORT jint JNI_OnLoad(JavaVM* vm, void* reserved) {
    std::thread worker(start);
    worker.detach();
    return JNI_VERSION_1_6;
}